package com.struckie;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

//public class LoginRegis extends AppCompatActivity {

    //@Override
    //protected void onCreate(Bundle savedInstanceState) {
        //super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_login_regis);
        //Button register=findViewById(R.id.button3);
        //setContentView(R.layout.activity_login_regis);
        //Button Home=findViewById(R.id.button2);


        //register.setOnClickListener(v -> startActivity(new Intent(v.getContext(),Regis.class)));
      //  Home.setOnClickListener(v -> startActivity(new Intent(v.getContext(),Home.class)));
    //}

public class LoginRegis extends AppCompatActivity {


    private Button button2;
    private Button button3;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_regis);


        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(LoginRegis.this, Home.class);
                startActivity(intent);


            }


        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(LoginRegis.this, Regis.class);
                startActivity(intent);


            }


        });



        }
}